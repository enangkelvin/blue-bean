<template>
  <div class="absolute inset-0 bg-black bg-opacity-20">
    <slot></slot>
  </div>
</template>
