// prettier.config.js
module.exports = {
  plugins: ["prettier-plugin-tailwindcss"],
};
