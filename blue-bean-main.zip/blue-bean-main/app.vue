<template>
  <div>
    
  </div>
  <NuxtPage />
</template>
